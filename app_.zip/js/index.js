function mensagem(){
    alert("O aplicativo está em construção...");
}